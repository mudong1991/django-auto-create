__version__ = '2.0'

default_app_config = 'formtools.apps.FormToolsConfig'
